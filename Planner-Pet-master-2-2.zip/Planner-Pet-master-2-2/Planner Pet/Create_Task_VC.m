//
//  Create_Task_VC.m
//  Planner Pet
//
//  Created by Isabella Tochterman on 4/12/19.
//  Copyright © 2019 Will Powers. All rights reserved.
//

#import "Create_Task_VC.h"

@interface Create_Task_VC ()
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UILabel *warningLabel;
@property (weak, nonatomic) IBOutlet UITextView *taskDescView;

@property BOOL filledOut;


@end


@implementation Create_Task_VC

- (void)viewDidLoad {
    
    NSLog(@"%@", _taskDescView.text);
    
    _taskDescView.layer.cornerRadius=_taskDescView.frame.size.height/10.0;
    
    _taskDescView.clipsToBounds=YES;
    
    
    
    
    [super viewDidLoad];
    
    _warningLabel.hidden = YES;
    
    CAGradientLayer *myFkngAwsmGrad = [[CAGradientLayer alloc] init];
    [myFkngAwsmGrad setColors:@[(id)[[UIColor blackColor] CGColor], (id)[[UIColor whiteColor] CGColor]]];
    myFkngAwsmGrad.frame = self.view.bounds;
    
    [self.view.layer insertSublayer:myFkngAwsmGrad atIndex:0];
    self.view.layer.backgroundColor = [[UIColor clearColor] CGColor];
    
    _appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    _CDContext = _appDelegate.persistentContainer.viewContext;
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    
    
}

- (IBAction)touchDate:(id)sender {
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    [self.addDate setInputView:datePicker];
    [datePicker addTarget:self action:@selector(saveDate:)
         forControlEvents:UIControlEventValueChanged];
    
    //    NSLog(@"The date is: %@", self.addDate.text);
    
}

//
-(void) saveDate: (UIDatePicker *) picker{
    _date = picker.date;
    NSDateFormatter * dateForm = [[NSDateFormatter alloc] init];
    dateForm.dateFormat = @"yyyy-MM-dd HH:mm";
    _addDate.text = [dateForm stringFromDate: _date];
    
    NSLog([dateForm stringFromDate: _date]);
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}
- (IBAction)didCancelCT:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)pushCTB:(id)sender {
    
    if(_date == nil || [_taskTitle.text isEqualToString:@""]){
        
        _warningLabel.hidden = NO;
    }
    
    //    if(_date == nil || _taskTitle == nil || _taskDescription == nil){
    //        //_createTaskButton.enabled = false;
    //        _filledOut = NO;
    //        _warningLabel.hidden = NO;
    //
    //
    //    }
    
    else{
        NSLog(@"Title is %@ ", _taskTitle.text);
        NSLog(@"Description is %@ ", _taskDescView.text);
        
        _entObj = [NSEntityDescription insertNewObjectForEntityForName: @"Task" inManagedObjectContext: _CDContext];
        
        [_entObj setValue: _date  forKey: @"dateStart"];
        [_entObj setValue: _taskDescView.text forKey: @"describe"];
        [_entObj setValue: _taskTitle.text forKey: @"title"];
        
        [_appDelegate saveContext];
        
        
        _taskTitle.delegate = self;
        _taskDescView.delegate = self;
        
        NSLog(@"%@", [_entObj valueForKey: @"title"]);
        
        [_appDelegate saveContext];
        
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
    
}

@end

